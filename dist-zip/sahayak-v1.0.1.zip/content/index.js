"use strict";
(() => {
  // <define:import.meta.env>
  var define_import_meta_env_default = {};

  // src/shared/constants.ts
  var import_meta = {};
  var getEnvApiKey = () => {
    try {
      if (typeof import_meta !== "undefined" && define_import_meta_env_default) {
        return String(define_import_meta_env_default.VITE_GEMINI_API_KEY || "").trim();
      }
    } catch {
    }
    return "";
  };
  var getEnvGroqApiKey = () => {
    try {
      if (typeof import_meta !== "undefined" && define_import_meta_env_default) {
        return String(define_import_meta_env_default.VITE_GROQ_API_KEY || "").trim();
      }
    } catch {
    }
    return "";
  };
  var DEFAULT_SETTINGS = {
    provider: "groq",
    fallbackProvider: "gemini",
    enableFallback: true,
    groqApiKey: getEnvGroqApiKey(),
    groqModel: "llama-3.1-8b-instant",
    geminiApiKey: getEnvApiKey(),
    preferredLang: "en",
    model: "gemini-3.8-flash"
  };
  var MESSAGE_TYPES = {
    // Key Validation
    VALIDATE_API_KEY: "MSG_VALIDATE_API_KEY",
    VALIDATE_GROQ_KEY: "MSG_VALIDATE_GROQ_KEY",
    // Page Scraper & Grounding
    EXTRACT_PAGE_CONTENT: "MSG_EXTRACT_PAGE_CONTENT",
    EXTRACT_YOUTUBE_TRANSCRIPT: "MSG_EXTRACT_YOUTUBE_TRANSCRIPT",
    PAGE_CONTENT_RESULT: "MSG_PAGE_CONTENT_RESULT",
    // Streaming Chat
    REQUEST_STREAM_CHAT: "MSG_REQUEST_STREAM_CHAT",
    STREAM_CHUNK: "MSG_STREAM_CHUNK",
    STREAM_END: "MSG_STREAM_END",
    STREAM_ERROR: "MSG_STREAM_ERROR",
    STREAM_RETRY: "MSG_STREAM_RETRY",
    STREAM_FALLBACK: "MSG_STREAM_FALLBACK",
    // Screen Multimodal
    CAPTURE_SCREEN: "MSG_CAPTURE_SCREEN",
    // Set-of-Marks & DOM Action Loop
    START_TASK: "MSG_START_TASK",
    PLAN_NEXT_ACTION: "MSG_PLAN_NEXT_ACTION",
    SCAN_INTERACTIVE_DOM: "MSG_SCAN_INTERACTIVE_DOM",
    DOM_MAP_RESULT: "MSG_DOM_MAP_RESULT",
    HIGHLIGHT_ELEMENT: "MSG_HIGHLIGHT_ELEMENT",
    EXECUTE_DOM_ACTION: "MSG_EXECUTE_DOM_ACTION",
    DOM_ACTION_RESULT: "MSG_DOM_ACTION_RESULT",
    CLEAR_BADGES: "MSG_CLEAR_BADGES",
    ABORT_TASK: "MSG_ABORT_TASK",
    SKIP_ACTION: "MSG_SKIP_ACTION",
    // Context Menu
    CONTEXT_MENU_TRIGGER: "MSG_CONTEXT_MENU_TRIGGER",
    // Milestone 2.5: Active Field Text Insertion
    INSERT_TEXT_ACTIVE_FIELD: "MSG_INSERT_TEXT_ACTIVE_FIELD"
  };
  var SENSITIVE_INPUT_REGEX = /(password|passwd|passcode|\bpass\b|\bpwd\b|\bpin\b|secret|token|cvv|cvc|creditcard|card_number|card-number|cardnumber|cc-number|exp-date|ssn|aadhaar|otp|authcode)/i;

  // src/content/readabilityScraper.ts
  var UNWANTED_SELECTORS = [
    "script",
    "style",
    "noscript",
    "template",
    "svg",
    "canvas",
    "iframe",
    "object",
    "embed",
    "video",
    "audio",
    "nav",
    "footer",
    "aside",
    "header",
    ".nav",
    ".navbar",
    ".navigation",
    ".menu",
    ".sidebar",
    ".ad",
    ".ads",
    ".advertisement",
    ".banner",
    ".social",
    ".share",
    ".comments",
    "#comments",
    ".cookie-banner",
    ".cc-window",
    "#onetrust-banner-sdk",
    "#CybotCookiebotDialog",
    '[id*="consent"]',
    '[class*="paywall"]',
    '[class*="cookie"]',
    ".modal-backdrop",
    '[aria-hidden="true"]',
    '[role="navigation"]',
    '[role="banner"]',
    '[role="contentinfo"]',
    '[role="complementary"]',
    'input[type="password"]',
    'input[autocomplete*="password"]',
    'input[autocomplete*="cc-"]',
    'input[autocomplete*="one-time-code"]',
    ".sensitive-box"
  ];
  var PRIMARY_ARTICLE_SELECTORS = [
    "article",
    "main",
    '[role="main"]',
    "#mw-content-text",
    // Wikipedia main text container
    ".article-content",
    ".post-content",
    ".entry-content",
    ".story-content",
    ".story-body",
    ".main-content",
    "#content"
  ];
  var MAX_WORD_LIMIT = 12e3;
  function isElementHidden(el) {
    if (!(el instanceof HTMLElement)) return false;
    if (el.hidden || el.style.display === "none" || el.style.visibility === "hidden") {
      return true;
    }
    if (el.style.opacity === "0" || el.style.fontSize === "0px" || el.style.fontSize === "0") {
      return true;
    }
    return false;
  }
  function extractMetaDescription() {
    const metaDesc = document.querySelector('meta[name="description"]')?.getAttribute("content") || document.querySelector('meta[property="og:description"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:description"]')?.getAttribute("content") || "";
    return metaDesc.trim();
  }
  function extractByline() {
    const authorMeta = document.querySelector('meta[name="author"]')?.getAttribute("content") || document.querySelector('meta[property="article:author"]')?.getAttribute("content") || document.querySelector('[rel="author"]')?.textContent || document.querySelector(".author, .byline")?.textContent || "";
    return authorMeta.trim().slice(0, 100);
  }
  function findPrimaryContainer() {
    for (const selector of PRIMARY_ARTICLE_SELECTORS) {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent || "";
        if (text.split(/\s+/).length > 60) {
          return el;
        }
      }
    }
    const candidates = Array.from(
      document.querySelectorAll(
        'main, article, section, [role="main"], body > div, #content, #main, .content, .main'
      )
    ).slice(0, 30);
    let bestContainer = document.body || document.documentElement || document.createElement("div");
    let highestScore = -1;
    for (const candidate of candidates) {
      if (isElementHidden(candidate)) continue;
      const paragraphs = candidate.querySelectorAll("p");
      if (paragraphs.length < 2) continue;
      let paragraphTextLength = 0;
      paragraphs.forEach((p) => {
        paragraphTextLength += (p.textContent || "").trim().length;
      });
      if (paragraphTextLength < 200) continue;
      const totalLength = (candidate.textContent || "").trim().length;
      if (totalLength === 0) continue;
      let linkTextLength = 0;
      candidate.querySelectorAll("a").forEach((a) => {
        linkTextLength += (a.textContent || "").trim().length;
      });
      const linkDensity = linkTextLength / totalLength;
      if (linkDensity > 0.55) continue;
      const score = paragraphTextLength * (1 - linkDensity) * Math.sqrt(paragraphs.length);
      if (score > highestScore) {
        highestScore = score;
        bestContainer = candidate;
      }
    }
    return bestContainer;
  }
  function nodeToMarkdown(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent || "";
      return text.replace(/[\r\n\t]+/g, " ").replace(/\s{2,}/g, " ");
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return "";
    }
    const el = node;
    const tagName = el.tagName.toLowerCase();
    const getChildrenMarkdown = () => {
      let result = "";
      for (let i = 0; i < el.childNodes.length; i++) {
        result += nodeToMarkdown(el.childNodes[i]);
      }
      return result;
    };
    switch (tagName) {
      case "h1": {
        const text = getChildrenMarkdown().trim();
        return text ? `

# ${text}

` : "";
      }
      case "h2": {
        const text = getChildrenMarkdown().trim();
        return text ? `

## ${text}

` : "";
      }
      case "h3": {
        const text = getChildrenMarkdown().trim();
        return text ? `

### ${text}

` : "";
      }
      case "h4":
      case "h5":
      case "h6": {
        const text = getChildrenMarkdown().trim();
        return text ? `

#### ${text}

` : "";
      }
      case "p": {
        const text = getChildrenMarkdown().trim();
        return text ? `

${text}

` : "";
      }
      case "blockquote": {
        const text = getChildrenMarkdown().trim();
        return text ? `

> ${text.split("\n").join("\n> ")}

` : "";
      }
      case "pre": {
        const text = el.textContent || "";
        return `

\`\`\`
${text.trim()}
\`\`\`

`;
      }
      case "code": {
        if (el.parentElement?.tagName.toLowerCase() === "pre") {
          return el.textContent || "";
        }
        const text = el.textContent || "";
        return text ? ` \`${text.trim()}\` ` : "";
      }
      case "ul": {
        let listMd = "\n\n";
        el.querySelectorAll(":scope > li").forEach((li) => {
          const itemText = nodeToMarkdown(li).trim();
          if (itemText) {
            listMd += `- ${itemText}
`;
          }
        });
        return listMd + "\n";
      }
      case "ol": {
        let listMd = "\n\n";
        let idx = 1;
        el.querySelectorAll(":scope > li").forEach((li) => {
          const itemText = nodeToMarkdown(li).trim();
          if (itemText) {
            listMd += `${idx}. ${itemText}
`;
            idx++;
          }
        });
        return listMd + "\n";
      }
      case "li": {
        return getChildrenMarkdown().trim();
      }
      case "table": {
        return renderTableToMarkdown(el);
      }
      case "strong":
      case "b": {
        const text = getChildrenMarkdown().trim();
        return text ? `**${text}**` : "";
      }
      case "em":
      case "i": {
        const text = getChildrenMarkdown().trim();
        return text ? `*${text}*` : "";
      }
      case "br": {
        return "\n";
      }
      case "hr": {
        return "\n\n---\n\n";
      }
      default: {
        return getChildrenMarkdown();
      }
    }
  }
  function renderTableToMarkdown(table) {
    const rows = table.querySelectorAll("tr");
    if (rows.length === 0) return "";
    let markdown = "\n\n";
    let hasHeader = false;
    rows.forEach((row, rowIndex) => {
      const cells = row.querySelectorAll("th, td");
      if (cells.length === 0) return;
      const rowValues = Array.from(cells).map(
        (cell) => (cell.textContent || "").trim().replace(/\|/g, "\\|").replace(/\s+/g, " ")
      );
      markdown += `| ${rowValues.join(" | ")} |
`;
      if (rowIndex === 0) {
        const isHeaderRow = row.querySelector("th") !== null || rows.length > 1;
        if (isHeaderRow && !hasHeader) {
          hasHeader = true;
          const separators = rowValues.map(() => "---");
          markdown += `| ${separators.join(" | ")} |
`;
        }
      }
    });
    return markdown + "\n\n";
  }
  function extractPageContent() {
    const startTime = performance.now();
    const title = (document.title || "").trim();
    const url = window.location.href;
    const description = extractMetaDescription();
    const byline = extractByline();
    const container = findPrimaryContainer() || document.body || document.documentElement || document.createElement("div");
    const clone = container.cloneNode(true);
    clone.querySelectorAll('input[type="password"], input[autocomplete*="password"], input[autocomplete*="cc-"], input[autocomplete*="one-time-code"], .sensitive-box').forEach((el) => {
      el.remove();
    });
    UNWANTED_SELECTORS.forEach((sel) => {
      clone.querySelectorAll(sel).forEach((node) => node.remove());
    });
    clone.querySelectorAll("*").forEach((el) => {
      if (isElementHidden(el)) {
        el.remove();
      }
    });
    let rawMarkdown = nodeToMarkdown(clone);
    rawMarkdown = rawMarkdown.replace(/[ \t]+/g, " ").replace(/\n\s+\n/g, "\n\n").replace(/\n{3,}/g, "\n\n").trim();
    const words = rawMarkdown.split(/\s+/).filter(Boolean);
    let wordCount = words.length;
    let isTruncated = false;
    let cleanText = rawMarkdown;
    if (wordCount > MAX_WORD_LIMIT) {
      cleanText = words.slice(0, MAX_WORD_LIMIT).join(" ");
      cleanText += `

[Note: Page content truncated after ${MAX_WORD_LIMIT} words for optimal processing.]`;
      wordCount = MAX_WORD_LIMIT;
      isTruncated = true;
    }
    const durationMs = Math.round(performance.now() - startTime);
    console.log(
      `[Sahayak Scraper] Extracted ${wordCount} words from "${title}" in ${durationMs}ms.`
    );
    return {
      title,
      cleanText,
      url,
      wordCount,
      description,
      byline,
      isTruncated
    };
  }

  // src/content/youtubeTranscript.ts
  function isYouTubeWatchUrl(rawUrl = window.location.href) {
    try {
      const u = new URL(rawUrl);
      const isYTHost = u.hostname.includes("youtube.com") || u.hostname === "youtu.be";
      if (!isYTHost) return false;
      if (u.pathname === "/watch" && u.searchParams.has("v")) return true;
      if (u.pathname.startsWith("/shorts/")) return true;
      return false;
    } catch {
      return false;
    }
  }
  function extractYouTubeVideoId(rawUrl = window.location.href) {
    try {
      const u = new URL(rawUrl);
      if (u.hostname === "youtu.be") {
        return u.pathname.slice(1).split("?")[0] || null;
      }
      if (u.pathname === "/watch") {
        return u.searchParams.get("v");
      }
      if (u.pathname.startsWith("/shorts/")) {
        return u.pathname.split("/")[2] || null;
      }
      return null;
    } catch {
      return null;
    }
  }
  function formatTimestamp(seconds) {
    const totalSeconds = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor(totalSeconds % 3600 / 60);
    const secs = totalSeconds % 60;
    if (hours > 0) {
      return `[${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(
        secs
      ).padStart(2, "0")}]`;
    }
    return `[${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}]`;
  }
  function decodeHtmlEntities(rawText) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = rawText;
    return textarea.value.replace(/[\r\n\t]+/g, " ").replace(/\s{2,}/g, " ").trim();
  }
  function extractVideoTitle() {
    const titleEl = document.querySelector("ytd-watch-metadata #title h1 yt-formatted-string") || document.querySelector("h1.ytd-watch-metadata yt-formatted-string") || document.querySelector("ytd-video-primary-info-renderer h1 yt-formatted-string") || document.querySelector("h1.title yt-formatted-string");
    if (titleEl && titleEl.textContent) {
      return titleEl.textContent.trim();
    }
    return document.title.replace(/\s*-\s*YouTube$/i, "").trim();
  }
  function extractChannelName() {
    const channelEl = document.querySelector("ytd-watch-metadata #channel-name a") || document.querySelector("#owner #channel-name yt-formatted-string a") || document.querySelector("#upload-info #channel-name a") || document.querySelector("ytd-channel-name a");
    return (channelEl?.textContent || "").trim();
  }
  function extractDescription() {
    const descEl = document.querySelector("ytd-watch-metadata #description yt-formatted-string") || document.querySelector("#description-inline-expander") || document.querySelector('meta[name="description"]');
    if (descEl) {
      if (descEl.getAttribute("content")) {
        return (descEl.getAttribute("content") || "").trim();
      }
      return (descEl.textContent || "").trim();
    }
    return "";
  }
  function extractChapters(description) {
    const chapters = [];
    const lines = description.split("\n");
    const timestampRegex = /\b(\d{1,2}:\d{2}(?::\d{2})?)\s+(.+)/;
    for (const line of lines) {
      const match = line.match(timestampRegex);
      if (match) {
        chapters.push(`${match[1]} - ${match[2].trim()}`);
      }
    }
    return chapters;
  }
  function extractJsonArray(text, key) {
    const marker = `"${key}":`;
    const idx = text.indexOf(marker);
    if (idx === -1) return null;
    const start = text.indexOf("[", idx + marker.length);
    if (start === -1) return null;
    let depth = 0;
    let inString = false;
    let escape = false;
    for (let i = start; i < text.length; i++) {
      const char = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (char === "\\") {
        escape = true;
        continue;
      }
      if (char === '"') {
        inString = !inString;
        continue;
      }
      if (!inString) {
        if (char === "[") depth++;
        else if (char === "]") {
          depth--;
          if (depth === 0) {
            const jsonStr = text.slice(start, i + 1);
            try {
              const parsed = JSON.parse(jsonStr);
              if (Array.isArray(parsed) && parsed.length > 0) {
                return parsed;
              }
            } catch {
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  async function findCaptionTracks() {
    const scripts = Array.from(document.querySelectorAll("script"));
    for (const script of scripts) {
      const content = script.textContent || "";
      if (content.includes("captionTracks")) {
        const tracks = extractJsonArray(content, "captionTracks");
        if (tracks && tracks.length > 0) {
          return tracks;
        }
      }
    }
    try {
      const win = window;
      const playerResponse = win.ytInitialPlayerResponse || win.ytplayer?.config?.args?.raw_player_response;
      if (playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks) {
        return playerResponse.captions.playerCaptionsTracklistRenderer.captionTracks;
      }
    } catch {
    }
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 2500);
      const response = await fetch(window.location.href, {
        credentials: "same-origin",
        signal: controller.signal
      });
      clearTimeout(timeout);
      if (response.ok) {
        const html = await response.text();
        const tracks = extractJsonArray(html, "captionTracks");
        if (tracks && tracks.length > 0) {
          return tracks;
        }
      }
    } catch (err) {
      console.debug("[YouTubeTranscript] Page fetch for captions skipped or timed out:", err);
    }
    return [];
  }
  function selectBestTrack(tracks, preferredLang = "en") {
    if (tracks.length === 0) return null;
    const langCodes = preferredLang === "hinglish" ? ["hi", "hi-IN", "en", "en-US", "en-GB"] : ["en", "en-US", "en-GB", "hi", "hi-IN"];
    for (const code of langCodes) {
      const manualMatch = tracks.find(
        (t) => t.languageCode?.toLowerCase() === code && t.kind !== "asr"
      );
      if (manualMatch) return manualMatch;
    }
    for (const code of langCodes) {
      const asrMatch = tracks.find((t) => t.languageCode?.toLowerCase() === code);
      if (asrMatch) return asrMatch;
    }
    return tracks[0];
  }
  async function fetchAndParseXmlTranscript(baseUrl) {
    const res = await fetch(baseUrl);
    if (!res.ok) {
      throw new Error(`Failed to fetch caption stream: HTTP ${res.status}`);
    }
    const xmlText = await res.text();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, "text/xml");
    const textNodes = Array.from(xmlDoc.querySelectorAll("text"));
    const segments = [];
    textNodes.forEach((node) => {
      const start = parseFloat(node.getAttribute("start") || "0");
      const dur = parseFloat(node.getAttribute("dur") || "0");
      const rawContent = node.textContent || "";
      const cleanContent = decodeHtmlEntities(rawContent);
      if (cleanContent) {
        segments.push({
          start,
          duration: dur,
          timestamp: formatTimestamp(start),
          text: cleanContent
        });
      }
    });
    return segments;
  }
  function formatSegmentsToDialogue(segments) {
    if (segments.length === 0) return "";
    const formattedLines = [];
    let currentTimestamp = segments[0].timestamp;
    let currentGroupText = [];
    let groupStartTime = segments[0].start;
    segments.forEach((seg) => {
      const timeDelta = seg.start - groupStartTime;
      const wordCount = currentGroupText.join(" ").split(/\s+/).length;
      if (timeDelta >= 18 || wordCount >= 35) {
        if (currentGroupText.length > 0) {
          formattedLines.push(`${currentTimestamp} ${currentGroupText.join(" ")}`);
        }
        currentTimestamp = seg.timestamp;
        currentGroupText = [seg.text];
        groupStartTime = seg.start;
      } else {
        currentGroupText.push(seg.text);
      }
    });
    if (currentGroupText.length > 0) {
      formattedLines.push(`${currentTimestamp} ${currentGroupText.join(" ")}`);
    }
    return formattedLines.join("\n");
  }
  async function extractYouTubeTranscript(preferredLang = "en") {
    const url = window.location.href;
    const videoId = extractYouTubeVideoId(url) || "";
    const title = extractVideoTitle();
    const channelName = extractChannelName();
    const description = extractDescription();
    const chapters = extractChapters(description);
    if (!videoId) {
      throw new Error("Not an active YouTube video watch URL.");
    }
    const tracks = await findCaptionTracks();
    const bestTrack = selectBestTrack(tracks, preferredLang);
    if (!bestTrack || !bestTrack.baseUrl) {
      console.warn("[YouTubeTranscript] Captions unavailable. Using description & chapter fallback.");
      const fallbackText = [
        `[Video Metadata]`,
        `Title: ${title}`,
        `Channel: ${channelName}`,
        `URL: ${url}`,
        chapters.length > 0 ? `
[Chapters]
${chapters.join("\n")}` : "",
        description ? `
[Description]
${description.slice(0, 3e3)}` : ""
      ].filter(Boolean).join("\n");
      return {
        videoId,
        title,
        channelName,
        url,
        hasCaptions: false,
        transcript: fallbackText,
        segments: [],
        description,
        chapters,
        wordCount: fallbackText.split(/\s+/).filter(Boolean).length
      };
    }
    const segments = await fetchAndParseXmlTranscript(bestTrack.baseUrl);
    const formattedTranscript = formatSegmentsToDialogue(segments);
    const wordCount = formattedTranscript.split(/\s+/).filter(Boolean).length;
    console.log(
      `[YouTubeTranscript] Successfully extracted ${segments.length} segments (${wordCount} words) in ${bestTrack.languageCode}.`
    );
    return {
      videoId,
      title,
      channelName,
      url,
      hasCaptions: true,
      captionLanguage: bestTrack.languageCode,
      isAutoGenerated: bestTrack.kind === "asr",
      transcript: formattedTranscript,
      segments,
      description,
      chapters,
      wordCount
    };
  }

  // src/content/textInserter.ts
  function findActiveEditableElement() {
    let el = document.activeElement;
    while (el && el.shadowRoot && el.shadowRoot.activeElement) {
      el = el.shadowRoot.activeElement;
    }
    if (!el) return null;
    if (el instanceof HTMLTextAreaElement) {
      return el;
    }
    if (el instanceof HTMLInputElement) {
      const type = (el.type || "text").toLowerCase();
      const nonTextTypes = [
        "button",
        "submit",
        "reset",
        "checkbox",
        "radio",
        "file",
        "image",
        "color",
        "range",
        "hidden"
      ];
      if (!nonTextTypes.includes(type) && !el.readOnly && !el.disabled) {
        return el;
      }
    }
    if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
      return el;
    }
    const focused = document.querySelector(
      'textarea:focus, input:focus, [contenteditable="true"]:focus, [role="textbox"]:focus'
    );
    if (focused) {
      return focused;
    }
    return null;
  }
  function insertTextIntoElement(el, text) {
    try {
      el.focus();
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        const start = el.selectionStart ?? el.value.length;
        const end = el.selectionEnd ?? el.value.length;
        const originalValue = el.value || "";
        const newValue = originalValue.slice(0, start) + text + originalValue.slice(end);
        const prototype = el instanceof HTMLInputElement ? window.HTMLInputElement.prototype : window.HTMLTextAreaElement.prototype;
        const valueSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
        if (valueSetter) {
          valueSetter.call(el, newValue);
        } else {
          el.value = newValue;
        }
        const newPos = start + text.length;
        try {
          el.setSelectionRange(newPos, newPos);
        } catch {
        }
        el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        return {
          success: true,
          elementTag: el.tagName.toLowerCase()
        };
      }
      if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
        let inserted = false;
        try {
          inserted = document.execCommand("insertText", false, text);
        } catch {
        }
        if (!inserted) {
          const sel = window.getSelection();
          if (sel && sel.rangeCount > 0) {
            const range = sel.getRangeAt(0);
            range.deleteContents();
            const textNode = document.createTextNode(text);
            range.insertNode(textNode);
            range.setStartAfter(textNode);
            range.collapse(true);
            sel.removeAllRanges();
            sel.addRange(range);
            inserted = true;
          } else {
            el.textContent = (el.textContent || "") + text;
            inserted = true;
          }
        }
        el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        return {
          success: true,
          elementTag: el.tagName.toLowerCase()
        };
      }
      return {
        success: false,
        error: "ELEMENT_NOT_EDITABLE"
      };
    } catch (err) {
      return {
        success: false,
        error: err.message || "Insertion failed"
      };
    }
  }

  // src/content/somOverlay.ts
  var SOM_CONTAINER_ID = "sahayak-som-container";
  var SOM_INLINE_STYLE_ID = "sahayak-som-inline-style";
  var HIGHLIGHT_CLASS = "sahayak-highlight-target";
  var BADGE_CLASS = "sahayak-badge";
  var BADGE_FIXED_CLASS = "sahayak-badge-fixed";
  var BADGE_TARGET_CLASS = "sahayak-badge-target";
  var INLINE_OVERLAY_CSS = `
#${SOM_CONTAINER_ID} {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none !important;
  z-index: 2147483647 !important;
  overflow: visible;
  margin: 0;
  padding: 0;
}

.${BADGE_CLASS} {
  position: absolute;
  pointer-events: none !important;
  background: #facc15 !important;
  color: #000000 !important;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
  font-size: 11px !important;
  font-weight: 800 !important;
  line-height: 1 !important;
  padding: 2px 6px !important;
  border-radius: 9999px !important;
  border: 1.5px solid #000000 !important;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4) !important;
  transform: translate(-50%, -50%) !important;
  user-select: none !important;
  white-space: nowrap !important;
  transition: transform 0.15s ease-out, background-color 0.15s ease-out !important;
}

.${BADGE_FIXED_CLASS} {
  position: fixed !important;
}

.${BADGE_TARGET_CLASS} {
  background: #38bdf8 !important;
  color: #0f172a !important;
  border-color: #0284c7 !important;
  box-shadow: 0 0 12px rgba(56, 189, 248, 0.9), 0 2px 6px rgba(0, 0, 0, 0.4) !important;
  transform: translate(-50%, -50%) scale(1.18) !important;
  z-index: 2147483647 !important;
}

.${HIGHLIGHT_CLASS} {
  outline: 3px solid #38bdf8 !important;
  outline-offset: 3px !important;
  animation: sahayak-pulse 1.5s infinite alternate ease-in-out !important;
}

@keyframes sahayak-pulse {
  0% {
    outline-color: #38bdf8;
    box-shadow: 0 0 8px rgba(56, 189, 248, 0.5);
  }
  100% {
    outline-color: #f43f5e;
    box-shadow: 0 0 16px rgba(244, 63, 94, 0.8);
  }
}
`;
  function ensureOverlayStyles() {
    if (typeof document === "undefined") return;
    if (!document.getElementById(SOM_INLINE_STYLE_ID)) {
      const styleEl = document.createElement("style");
      styleEl.id = SOM_INLINE_STYLE_ID;
      styleEl.textContent = INLINE_OVERLAY_CSS;
      (document.head || document.documentElement).appendChild(styleEl);
    }
  }
  function getOrCreateOverlayContainer() {
    if (typeof document === "undefined") return null;
    let container = document.getElementById(SOM_CONTAINER_ID);
    if (!container) {
      ensureOverlayStyles();
      container = document.createElement("div");
      container.id = SOM_CONTAINER_ID;
      container.setAttribute("aria-hidden", "true");
      container.setAttribute("data-sahayak-overlay", "true");
      container.style.cssText = "position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 2147483647; overflow: visible; margin: 0; padding: 0;";
      const parent = document.body || document.documentElement;
      if (parent) {
        parent.appendChild(container);
      }
    }
    return container;
  }
  function clampCoord(val, min, max) {
    return Math.max(min, Math.min(val, max));
  }
  function renderBadges(elements) {
    if (typeof document === "undefined") {
      return { success: false, renderedCount: 0 };
    }
    clearBadges();
    if (!elements || elements.length === 0) {
      return { success: true, renderedCount: 0 };
    }
    const container = getOrCreateOverlayContainer();
    if (!container) {
      return { success: false, renderedCount: 0 };
    }
    const vw = typeof window !== "undefined" ? window.innerWidth : 1280;
    const vh = typeof window !== "undefined" ? window.innerHeight : 800;
    let renderedCount = 0;
    for (const el of elements) {
      const badge = document.createElement("div");
      badge.className = BADGE_CLASS;
      badge.setAttribute("data-action-id", String(el.id));
      badge.textContent = `#${el.id}`;
      if (el.isFixed) {
        badge.classList.add(BADGE_FIXED_CLASS);
        const posX = clampCoord(el.rect.x, 10, vw - 20);
        const posY = clampCoord(el.rect.y, 10, vh - 20);
        badge.style.position = "fixed";
        badge.style.left = `${posX}px`;
        badge.style.top = `${posY}px`;
      } else {
        const posX = Math.max(10, el.rect.left);
        const posY = Math.max(10, el.rect.top);
        badge.style.position = "absolute";
        badge.style.left = `${posX}px`;
        badge.style.top = `${posY}px`;
      }
      container.appendChild(badge);
      renderedCount++;
    }
    return { success: true, renderedCount };
  }
  function highlightTargetElement(actionId) {
    if (typeof document === "undefined") {
      return { success: false, highlightedId: null };
    }
    const prevHighlighted = document.querySelectorAll(`.${HIGHLIGHT_CLASS}`);
    prevHighlighted.forEach((el) => el.classList.remove(HIGHLIGHT_CLASS));
    const prevBadges = document.querySelectorAll(`.${BADGE_TARGET_CLASS}`);
    prevBadges.forEach((el) => el.classList.remove(BADGE_TARGET_CLASS));
    if (actionId === null || actionId === void 0) {
      return { success: true, highlightedId: null };
    }
    const targetEl = getElementByActionId(actionId);
    if (targetEl) {
      targetEl.classList.add(HIGHLIGHT_CLASS);
      try {
        targetEl.scrollIntoView({
          behavior: "smooth",
          block: "nearest",
          inline: "nearest"
        });
      } catch {
      }
    }
    const container = document.getElementById(SOM_CONTAINER_ID);
    if (container) {
      const badge = container.querySelector(`[data-action-id="${actionId}"]`);
      if (badge) {
        badge.classList.add(BADGE_TARGET_CLASS);
      }
    }
    return { success: Boolean(targetEl), highlightedId: actionId };
  }
  function clearBadges() {
    if (typeof document === "undefined") {
      return { success: true };
    }
    const container = document.getElementById(SOM_CONTAINER_ID);
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    const highlighted = document.querySelectorAll(`.${HIGHLIGHT_CLASS}`);
    highlighted.forEach((el) => el.classList.remove(HIGHLIGHT_CLASS));
    return { success: true };
  }

  // src/content/somMapper.ts
  var CANDIDATE_SELECTOR = [
    "a[href]",
    "button",
    'input:not([type="hidden"])',
    "select",
    "textarea",
    '[role="button"]',
    '[role="link"]',
    '[role="checkbox"]',
    '[role="radio"]',
    '[role="switch"]',
    '[role="combobox"]',
    '[role="menuitem"]',
    '[role="menuitemcheckbox"]',
    '[role="menuitemradio"]',
    '[role="tab"]',
    '[role="option"]',
    '[role="searchbox"]',
    '[role="textbox"]',
    '[contenteditable="true"]',
    '[contenteditable=""]',
    '[tabindex]:not([tabindex="-1"])',
    "summary"
  ].join(", ");
  var scannedElementRegistry = /* @__PURE__ */ new Map();
  function getElementByActionId(id) {
    return scannedElementRegistry.get(id);
  }
  function clearScannedElements() {
    scannedElementRegistry.clear();
  }
  function isSensitiveElement(el) {
    if (!el) return false;
    if (el instanceof HTMLInputElement && el.type && el.type.toLowerCase() === "password") {
      return true;
    }
    const autocomplete = (el.getAttribute("autocomplete") || "").toLowerCase();
    if (autocomplete.includes("password") || autocomplete.includes("cc-") || autocomplete.includes("one-time-code") || autocomplete.includes("transaction-")) {
      return true;
    }
    const attributesToInspect = [
      el.getAttribute("name"),
      el.getAttribute("id"),
      el.getAttribute("aria-label"),
      el.getAttribute("placeholder"),
      el.getAttribute("title"),
      el.className,
      el.getAttribute("data-testid")
    ];
    for (const attr of attributesToInspect) {
      if (attr && typeof attr === "string" && SENSITIVE_INPUT_REGEX.test(attr)) {
        return true;
      }
    }
    return false;
  }
  function isElementVisibleInViewport(el, options = {}) {
    const minWidth = options.minWidth ?? 8;
    const minHeight = options.minHeight ?? 8;
    const checkStyle = options.checkComputedStyle ?? true;
    const viewportOnly = options.viewportOnly ?? true;
    const dummyRect = {
      x: 0,
      y: 0,
      width: 0,
      height: 0,
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      toJSON: () => ({})
    };
    if (!el || !el.isConnected) {
      return { visible: false, rect: dummyRect, isFixed: false };
    }
    let isFixed = false;
    if (checkStyle && typeof window !== "undefined" && typeof window.getComputedStyle === "function") {
      try {
        const style = window.getComputedStyle(el);
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || parseFloat(style.opacity || "1") < 0.1 || style.pointerEvents === "none") {
          return { visible: false, rect: dummyRect, isFixed: false };
        }
        isFixed = style.position === "fixed" || style.position === "sticky";
      } catch {
      }
    }
    let rect = dummyRect;
    try {
      rect = el.getBoundingClientRect();
    } catch {
      return { visible: false, rect: dummyRect, isFixed: false };
    }
    if (rect.width < minWidth || rect.height < minHeight) {
      return { visible: false, rect, isFixed };
    }
    if (viewportOnly && typeof window !== "undefined") {
      const vh = window.innerHeight || document.documentElement.clientHeight || 0;
      const vw = window.innerWidth || document.documentElement.clientWidth || 0;
      if (vh > 0 && vw > 0) {
        const inView = rect.bottom > 0 && rect.top < vh && rect.right > 0 && rect.left < vw;
        if (!inView) {
          return { visible: false, rect, isFixed };
        }
      }
    }
    return { visible: true, rect, isFixed };
  }
  function getElementLabel(el) {
    if (!el) return "";
    const clean = (text) => {
      if (!text) return "";
      return text.replace(/\s+/g, " ").trim();
    };
    if (el.id && typeof document !== "undefined") {
      try {
        const safeId = CSS.escape ? CSS.escape(el.id) : el.id;
        const label = document.querySelector(`label[for="${safeId}"]`);
        if (label) {
          const text = clean(label.innerText || label.textContent);
          if (text) return text.slice(0, 100);
        }
      } catch {
      }
    }
    try {
      const parentLabel = el.closest("label");
      if (parentLabel) {
        const clone = parentLabel.cloneNode(true);
        const innerInput = clone.querySelector("input, select, textarea");
        if (innerInput && innerInput.parentNode) {
          innerInput.parentNode.removeChild(innerInput);
        }
        const text = clean(clone.innerText || clone.textContent);
        if (text) return text.slice(0, 100);
      }
    } catch {
    }
    const ariaLabel = el.getAttribute("aria-label");
    if (ariaLabel && clean(ariaLabel)) {
      return clean(ariaLabel).slice(0, 100);
    }
    const ariaLabelledBy = el.getAttribute("aria-labelledby");
    if (ariaLabelledBy && typeof document !== "undefined") {
      const parts = [];
      for (const id of ariaLabelledBy.split(/\s+/)) {
        if (!id) continue;
        const target = document.getElementById(id);
        if (target) {
          parts.push(clean(target.innerText || target.textContent));
        }
      }
      const combined = clean(parts.join(" "));
      if (combined) return combined.slice(0, 100);
    }
    const placeholder = el.getAttribute("placeholder");
    if (placeholder && clean(placeholder)) {
      return clean(placeholder).slice(0, 100);
    }
    const tag = el.tagName.toLowerCase();
    if (tag === "button" || tag === "a" || tag === "summary" || el.getAttribute("role") === "button" || el.getAttribute("role") === "link" || el.getAttribute("role") === "tab") {
      const inner = clean(el.innerText || el.textContent);
      if (inner) return inner.slice(0, 100);
      const img = el.querySelector("img[alt]");
      if (img) {
        const alt = clean(img.getAttribute("alt"));
        if (alt) return alt.slice(0, 100);
      }
      const svg = el.querySelector("svg");
      if (svg) {
        const svgTitle = clean(svg.getAttribute("aria-label") || svg.querySelector("title")?.textContent);
        if (svgTitle) return svgTitle.slice(0, 100);
      }
    }
    if (el instanceof HTMLInputElement) {
      const type = (el.type || "text").toLowerCase();
      if ((type === "submit" || type === "button" || type === "reset") && el.value) {
        const val = clean(el.value);
        if (val) return val.slice(0, 100);
      }
    }
    const title = el.getAttribute("title");
    if (title && clean(title)) {
      return clean(title).slice(0, 100);
    }
    const name = el.getAttribute("name");
    if (name && clean(name)) {
      return clean(name).slice(0, 100);
    }
    const role = el.getAttribute("role");
    if (role) {
      return `${role} element`;
    }
    return `${tag} element`;
  }
  function generateElementSelector(el) {
    if (!el || !el.tagName) return "";
    const tag = el.tagName.toLowerCase();
    if (el.id && typeof document !== "undefined") {
      try {
        const safeId = CSS.escape ? CSS.escape(el.id) : el.id;
        if (document.querySelectorAll(`#${safeId}`).length === 1) {
          return `#${safeId}`;
        }
      } catch {
      }
    }
    const name = el.getAttribute("name");
    if (name && typeof document !== "undefined") {
      try {
        const safeName = CSS.escape ? CSS.escape(name) : name;
        const selector = `${tag}[name="${safeName}"]`;
        if (document.querySelectorAll(selector).length === 1) {
          return selector;
        }
      } catch {
      }
    }
    const testId = el.getAttribute("data-testid");
    if (testId && typeof document !== "undefined") {
      try {
        const safeTestId = CSS.escape ? CSS.escape(testId) : testId;
        const selector = `${tag}[data-testid="${safeTestId}"]`;
        if (document.querySelectorAll(selector).length === 1) {
          return selector;
        }
      } catch {
      }
    }
    const ariaLabel = el.getAttribute("aria-label");
    const role = el.getAttribute("role");
    if (ariaLabel && typeof document !== "undefined") {
      try {
        const safeLabel = CSS.escape ? CSS.escape(ariaLabel) : ariaLabel;
        const selector = role ? `[role="${role}"][aria-label="${safeLabel}"]` : `${tag}[aria-label="${safeLabel}"]`;
        if (document.querySelectorAll(selector).length === 1) {
          return selector;
        }
      } catch {
      }
    }
    const path = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && path.length < 4) {
      let selector = current.tagName.toLowerCase();
      if (current.id && CSS.escape) {
        selector += `#${CSS.escape(current.id)}`;
        path.unshift(selector);
        break;
      } else {
        let nth = 1;
        let sibling = current.previousElementSibling;
        while (sibling) {
          if (sibling.tagName.toLowerCase() === current.tagName.toLowerCase()) {
            nth++;
          }
          sibling = sibling.previousElementSibling;
        }
        selector += `:nth-of-type(${nth})`;
      }
      path.unshift(selector);
      current = current.parentElement;
    }
    return path.join(" > ") || tag;
  }
  function extractCurrentValue(el) {
    if (el instanceof HTMLInputElement) {
      const type = (el.type || "text").toLowerCase();
      if (type === "checkbox" || type === "radio") {
        return el.checked ? "checked" : "unchecked";
      }
      return el.value ? el.value.slice(0, 100) : "";
    }
    if (el instanceof HTMLTextAreaElement) {
      return el.value ? el.value.slice(0, 100) : "";
    }
    if (el instanceof HTMLSelectElement) {
      return el.value || "";
    }
    if (el.isContentEditable || el.getAttribute("contenteditable") === "true") {
      return (el.innerText || el.textContent || "").slice(0, 100);
    }
    return void 0;
  }
  function extractSelectOptions(el) {
    if (!(el instanceof HTMLSelectElement)) return void 0;
    const options = [];
    const maxOptions = 10;
    for (let i = 0; i < el.options.length && i < maxOptions; i++) {
      const opt = el.options[i];
      const text = (opt.text || opt.value || "").trim();
      if (text) {
        options.push(text);
      }
    }
    return options.length > 0 ? options : void 0;
  }
  function scanInteractiveElements(options = {}) {
    const startTime = typeof performance !== "undefined" ? performance.now() : Date.now();
    clearScannedElements();
    const viewportOnly = options.viewportOnly ?? true;
    const minWidth = options.minWidth ?? 8;
    const minHeight = options.minHeight ?? 8;
    const includeDisabled = options.includeDisabled ?? false;
    const viewport = {
      width: typeof window !== "undefined" ? window.innerWidth : 1280,
      height: typeof window !== "undefined" ? window.innerHeight : 800,
      scrollX: typeof window !== "undefined" ? window.scrollX : 0,
      scrollY: typeof window !== "undefined" ? window.scrollY : 0
    };
    const url = typeof window !== "undefined" ? window.location.href : "";
    const title = typeof document !== "undefined" ? document.title : "";
    if (typeof document === "undefined") {
      return {
        viewport,
        elements: [],
        url,
        title,
        scanDurationMs: 0,
        totalCandidates: 0,
        excludedSensitiveCount: 0
      };
    }
    let candidateNodes;
    try {
      candidateNodes = document.querySelectorAll(CANDIDATE_SELECTOR);
    } catch {
      candidateNodes = document.querySelectorAll("button, a, input, select, textarea");
    }
    const elements = [];
    let nextId = 1;
    let excludedSensitiveCount = 0;
    const parentClickableSet = /* @__PURE__ */ new Set();
    for (let i = 0; i < candidateNodes.length; i++) {
      const node = candidateNodes[i];
      if (!(node instanceof HTMLElement)) continue;
      if (node.parentElement && (parentClickableSet.has(node.parentElement) || node.parentElement.closest("button, a[href]"))) {
        const parentInteractive = node.parentElement.closest("button, a[href]");
        if (parentInteractive && parentInteractive !== node) {
          continue;
        }
      }
      if (isSensitiveElement(node)) {
        excludedSensitiveCount++;
        continue;
      }
      if (!includeDisabled) {
        const isDisabled = node.disabled === true || node.getAttribute("aria-disabled") === "true" || node.classList.contains("disabled");
        if (isDisabled) {
          continue;
        }
      }
      const { visible, rect, isFixed } = isElementVisibleInViewport(node, {
        minWidth,
        minHeight,
        viewportOnly
      });
      if (!visible) {
        continue;
      }
      const tag = node.tagName.toLowerCase();
      const type = node instanceof HTMLInputElement ? (node.type || "text").toLowerCase() : void 0;
      const name = node.getAttribute("name") || void 0;
      const role = node.getAttribute("role") || void 0;
      const placeholder = node.getAttribute("placeholder") || void 0;
      const label = getElementLabel(node);
      const currentValue = extractCurrentValue(node);
      const optionsList = extractSelectOptions(node);
      const selector = generateElementSelector(node);
      const elementRect = {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        top: Math.round(rect.top + (isFixed ? 0 : viewport.scrollY)),
        left: Math.round(rect.left + (isFixed ? 0 : viewport.scrollX))
      };
      const actionElement = {
        id: nextId,
        tag,
        type,
        name,
        label: label || `${tag} #${nextId}`,
        placeholder,
        currentValue,
        rect: elementRect,
        selector,
        role,
        options: optionsList,
        isFixed
      };
      scannedElementRegistry.set(nextId, node);
      if (tag === "button" || tag === "a" || role === "button") {
        parentClickableSet.add(node);
      }
      elements.push(actionElement);
      nextId++;
    }
    const endTime = typeof performance !== "undefined" ? performance.now() : Date.now();
    const scanDurationMs = Math.round((endTime - startTime) * 100) / 100;
    const hasPasswordField = typeof document !== "undefined" ? document.querySelector('input[type="password"]') !== null : false;
    const isSensitivePage = hasPasswordField;
    return {
      viewport,
      elements,
      url,
      title,
      scanDurationMs,
      totalCandidates: candidateNodes.length,
      excludedSensitiveCount,
      hasPasswordField,
      isSensitivePage
    };
  }

  // src/content/actionRunner.ts
  function dispatchMouseClickSequence(el) {
    const rect = el.getBoundingClientRect();
    const clientX = rect.left + rect.width / 2;
    const clientY = rect.top + rect.height / 2;
    const eventInit = {
      bubbles: true,
      cancelable: true,
      view: window,
      detail: 1,
      screenX: window.screenX + clientX,
      screenY: window.screenY + clientY,
      clientX,
      clientY,
      button: 0,
      buttons: 1
    };
    try {
      el.focus();
    } catch {
    }
    if (typeof PointerEvent !== "undefined") {
      el.dispatchEvent(new PointerEvent("pointerdown", eventInit));
    }
    el.dispatchEvent(new MouseEvent("mousedown", eventInit));
    if (typeof PointerEvent !== "undefined") {
      el.dispatchEvent(new PointerEvent("pointerup", eventInit));
    }
    el.dispatchEvent(new MouseEvent("mouseup", eventInit));
    if (typeof el.click === "function") {
      el.click();
    } else {
      el.dispatchEvent(new MouseEvent("click", eventInit));
    }
  }
  function typeIntoInput(el, text) {
    try {
      el.focus();
    } catch {
    }
    const tracker = el._valueTracker;
    if (tracker) {
      tracker.setValue("");
    }
    const prototype = el instanceof HTMLInputElement ? window.HTMLInputElement.prototype : window.HTMLTextAreaElement.prototype;
    const valueSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (valueSetter) {
      valueSetter.call(el, text);
    } else {
      el.value = text;
    }
    try {
      el.dispatchEvent(
        new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter" })
      );
    } catch {
    }
    if (typeof InputEvent !== "undefined") {
      el.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          cancelable: true,
          data: text,
          inputType: "insertText"
        })
      );
    } else {
      el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    }
    el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
  }
  function selectDropdownOption(el, optionValueOrText) {
    try {
      el.focus();
    } catch {
    }
    const target = optionValueOrText.trim().toLowerCase();
    let matchedIndex = -1;
    for (let i = 0; i < el.options.length; i++) {
      const opt = el.options[i];
      if (opt.value.toLowerCase() === target || opt.text && opt.text.trim().toLowerCase() === target || opt.text && opt.text.trim().toLowerCase().includes(target)) {
        matchedIndex = i;
        break;
      }
    }
    if (matchedIndex === -1 && el.options.length > 0) {
      matchedIndex = 0;
    }
    if (matchedIndex !== -1) {
      el.selectedIndex = matchedIndex;
      const prototype = window.HTMLSelectElement.prototype;
      const valueSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (valueSetter && el.options[matchedIndex]) {
        valueSetter.call(el, el.options[matchedIndex].value);
      }
      el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
      return true;
    }
    return false;
  }
  function performScroll(direction = "DOWN") {
    if (typeof window === "undefined") return;
    switch (direction) {
      case "UP":
        window.scrollBy({ top: -450, behavior: "smooth" });
        break;
      case "DOWN":
        window.scrollBy({ top: 450, behavior: "smooth" });
        break;
      case "TOP":
        window.scrollTo({ top: 0, behavior: "smooth" });
        break;
      case "BOTTOM":
        window.scrollTo({
          top: Math.max(
            document.body?.scrollHeight || 0,
            document.documentElement?.scrollHeight || 0
          ),
          behavior: "smooth"
        });
        break;
      default:
        window.scrollBy({ top: 450, behavior: "smooth" });
    }
  }
  async function executeAction(action) {
    const startTime = typeof performance !== "undefined" ? performance.now() : Date.now();
    if (!action || !action.actionType) {
      return {
        success: false,
        actionType: "WAIT",
        error: "NO_ACTION_SPECIFIED",
        executionTimeMs: 0
      };
    }
    const { actionType, targetElementId, targetSelector, value, scrollDirection } = action;
    if (actionType === "SCROLL") {
      performScroll(scrollDirection || "DOWN");
      const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
      return {
        success: true,
        actionType: "SCROLL",
        executionTimeMs: elapsed
      };
    }
    if (actionType === "WAIT") {
      await new Promise((resolve) => setTimeout(resolve, 800));
      const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
      return {
        success: true,
        actionType: "WAIT",
        executionTimeMs: elapsed
      };
    }
    if (actionType === "COMPLETED") {
      const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
      return {
        success: true,
        actionType: "COMPLETED",
        executionTimeMs: elapsed
      };
    }
    let targetEl = null;
    if (targetElementId !== void 0) {
      targetEl = getElementByActionId(targetElementId) || null;
    }
    if (!targetEl && targetSelector && typeof document !== "undefined") {
      try {
        targetEl = document.querySelector(targetSelector);
      } catch {
      }
    }
    if (!targetEl) {
      const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
      return {
        success: false,
        actionType,
        targetElementId,
        error: `ELEMENT_NOT_FOUND: Element #${targetElementId} could not be located in the current DOM.`,
        executionTimeMs: elapsed
      };
    }
    if (isSensitiveElement(targetEl)) {
      const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
      return {
        success: false,
        actionType,
        targetElementId,
        error: "SENSITIVE_FIELD_PROTECTED: Automated interaction with password/credential fields is blocked for your security.",
        executionTimeMs: elapsed
      };
    }
    const elementTag = targetEl.tagName.toLowerCase();
    try {
      targetEl.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest"
      });
    } catch {
    }
    await new Promise((resolve) => setTimeout(resolve, 60));
    try {
      if (actionType === "CLICK") {
        dispatchMouseClickSequence(targetEl);
        const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
        return {
          success: true,
          actionType: "CLICK",
          targetElementId,
          targetLabel: action.targetLabel,
          elementTag,
          executionTimeMs: elapsed
        };
      }
      if (actionType === "TYPE") {
        const textToType = value ?? "";
        if (targetEl instanceof HTMLInputElement || targetEl instanceof HTMLTextAreaElement) {
          typeIntoInput(targetEl, textToType);
        } else if (targetEl.isContentEditable || targetEl.getAttribute("contenteditable") === "true") {
          try {
            targetEl.focus();
          } catch {
          }
          targetEl.innerText = textToType;
          targetEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
          targetEl.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
        } else {
          targetEl.innerText = textToType;
          targetEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        }
        const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
        return {
          success: true,
          actionType: "TYPE",
          targetElementId,
          targetLabel: action.targetLabel,
          elementTag,
          executionTimeMs: elapsed
        };
      }
      if (actionType === "SELECT") {
        if (targetEl instanceof HTMLSelectElement) {
          const selected = selectDropdownOption(targetEl, value || "");
          const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
          return {
            success: selected,
            actionType: "SELECT",
            targetElementId,
            targetLabel: action.targetLabel,
            elementTag,
            error: selected ? void 0 : `Option "${value}" was not found in dropdown options.`,
            executionTimeMs: elapsed
          };
        } else {
          const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
          return {
            success: false,
            actionType: "SELECT",
            targetElementId,
            targetLabel: action.targetLabel,
            elementTag,
            error: "TARGET_NOT_A_SELECT: Target element is not a <select> element.",
            executionTimeMs: elapsed
          };
        }
      }
      return {
        success: false,
        actionType,
        targetElementId,
        error: `UNSUPPORTED_ACTION_TYPE: ${actionType}`,
        executionTimeMs: Math.round((performance.now() - startTime) * 100) / 100
      };
    } catch (err) {
      return {
        success: false,
        actionType,
        targetElementId,
        error: err.message || "Action execution failed.",
        executionTimeMs: Math.round((performance.now() - startTime) * 100) / 100
      };
    }
  }

  // src/content/index.ts
  console.log("[Sahayak Content] Content script loaded on:", window.location.href);
  var lastObservedUrl = window.location.href;
  function handleSpaNavigationDetected(source) {
    const currentUrl = window.location.href;
    if (currentUrl === lastObservedUrl && source !== "yt-navigate-finish") {
      return;
    }
    lastObservedUrl = currentUrl;
    console.log(`[Sahayak Content] SPA navigation detected via ${source}:`, currentUrl);
    clearBadges();
    clearScannedElements();
    try {
      chrome.runtime.sendMessage({
        type: "MSG_SPA_NAVIGATED",
        payload: {
          url: currentUrl,
          title: document.title || "",
          source
        }
      }).catch(() => {
      });
    } catch {
    }
  }
  window.addEventListener("yt-navigate-finish", () => {
    handleSpaNavigationDetected("yt-navigate-finish");
  });
  if (typeof history !== "undefined") {
    const origPushState = history.pushState;
    history.pushState = function(...args) {
      const res = origPushState.apply(this, args);
      setTimeout(() => handleSpaNavigationDetected("pushState"), 50);
      return res;
    };
    const origReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      const res = origReplaceState.apply(this, args);
      setTimeout(() => handleSpaNavigationDetected("replaceState"), 50);
      return res;
    };
  }
  window.addEventListener("popstate", () => {
    setTimeout(() => handleSpaNavigationDetected("popstate"), 50);
  });
  window.addEventListener("hashchange", () => {
    setTimeout(() => handleSpaNavigationDetected("hashchange"), 50);
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "MSG_CONTENT_PING") {
      sendResponse({
        status: "PONG",
        url: window.location.href,
        title: document.title,
        isYouTube: isYouTubeWatchUrl()
      });
      return true;
    }
    if (message?.type === MESSAGE_TYPES.EXTRACT_PAGE_CONTENT || message?.type === "MSG_EXTRACT_PAGE_CONTENT") {
      try {
        const extraction = extractPageContent();
        sendResponse({
          success: true,
          ...extraction
        });
      } catch (err) {
        console.error("[Sahayak Content] Failed to extract page content:", err);
        sendResponse({
          success: false,
          error: err.message || "DOM content extraction failed",
          title: document.title || "",
          cleanText: "",
          url: window.location.href,
          wordCount: 0
        });
      }
      return true;
    }
    if (message?.type === MESSAGE_TYPES.EXTRACT_YOUTUBE_TRANSCRIPT || message?.type === "MSG_EXTRACT_YOUTUBE_TRANSCRIPT") {
      const preferredLang = message?.payload?.preferredLang || "en";
      extractYouTubeTranscript(preferredLang).then((extraction) => {
        sendResponse({
          success: true,
          ...extraction
        });
      }).catch((err) => {
        console.error("[Sahayak Content] Failed to extract YouTube transcript:", err);
        sendResponse({
          success: false,
          error: err.message || "Failed to extract YouTube transcript",
          hasCaptions: false,
          transcript: "",
          wordCount: 0
        });
      });
      return true;
    }
    if (message?.type === MESSAGE_TYPES.INSERT_TEXT_ACTIVE_FIELD || message?.type === "MSG_INSERT_TEXT_ACTIVE_FIELD") {
      const textToInsert = message?.payload?.text || "";
      const activeEl = findActiveEditableElement();
      if (!activeEl) {
        sendResponse({
          success: false,
          error: "NO_ACTIVE_FIELD"
        });
        return true;
      }
      const result = insertTextIntoElement(activeEl, textToInsert);
      sendResponse(result);
      return true;
    }
    if (message?.type === MESSAGE_TYPES.SCAN_INTERACTIVE_DOM || message?.type === "MSG_SCAN_INTERACTIVE_DOM") {
      try {
        const scanResult = scanInteractiveElements(message?.payload || {});
        let renderedCount = 0;
        if (message?.payload?.renderBadges !== false) {
          const renderResult = renderBadges(scanResult.elements);
          renderedCount = renderResult.renderedCount;
        }
        sendResponse({
          success: true,
          actionMap: scanResult,
          count: scanResult.elements.length,
          renderedCount,
          scanDurationMs: scanResult.scanDurationMs,
          excludedSensitiveCount: scanResult.excludedSensitiveCount
        });
      } catch (err) {
        console.error("[Sahayak Content] DOM scanning failed:", err);
        sendResponse({
          success: false,
          error: err.message || "Interactive DOM scan failed",
          elements: []
        });
      }
      return true;
    }
    if (message?.type === MESSAGE_TYPES.HIGHLIGHT_ELEMENT || message?.type === "MSG_HIGHLIGHT_ELEMENT") {
      const targetId = message?.payload?.targetElementId ?? message?.payload?.actionId ?? null;
      const result = highlightTargetElement(targetId);
      sendResponse(result);
      return true;
    }
    if (message?.type === MESSAGE_TYPES.CLEAR_BADGES || message?.type === "MSG_CLEAR_BADGES") {
      clearBadges();
      clearScannedElements();
      sendResponse({ success: true, cleared: true });
      return true;
    }
    if (message?.type === MESSAGE_TYPES.EXECUTE_DOM_ACTION || message?.type === "MSG_EXECUTE_DOM_ACTION") {
      const action = message?.payload?.action;
      executeAction(action).then((result) => {
        sendResponse(result);
      }).catch((err) => {
        console.error("[Sahayak Content] Action execution failed:", err);
        sendResponse({
          success: false,
          actionType: action?.actionType || "WAIT",
          error: err.message || "Action execution threw an unexpected error",
          executionTimeMs: 0
        });
      });
      return true;
    }
    return false;
  });
})();
